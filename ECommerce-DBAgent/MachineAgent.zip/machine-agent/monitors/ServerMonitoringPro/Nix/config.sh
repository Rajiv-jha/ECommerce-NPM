#!/usr/bin/env bash
#
# This is a configuration for machine agents to gather metrics and properties.
#
# Copyright (c) AppDynamics, Inc., and its affiliates, 2014, 2015
# All Rights Reserved
# THIS IS UNPUBLISHED PROPRIETARY CODE OF APPDYNAMICS, INC.
# The copyright notice above does not evidence any
# actual or intended publication of such source code.

# Default Regular Expression filters which processes that should be monitored.
# This regex allows all type of processes except if it start with square bracket "[".
ALL_PROCESSES="^[^[].+"

# Default Regular Expression selects process class. This regex classifies processes by name (first word only).
# For example, the command (java newApp -Ddebug.mode=true) is classified based on the first word (java)
# Do not add the leading and ending slash
PROCESS_CLASS_BY_NAME="^[^ ]+"

# This variable filters which process that should monitored. The variable contains the regex pattern and For
# each process that is running, the full command line will be evaluated against the regex. Only if it qualifies,
# the process will be monitored.
export PROCESS_SELECTOR_REGEX="${ALL_PROCESSES}"

# This variable classifies the processes. The process class name is based on the regex specified in this variable.
# The regex is evaluated against the full command line, and the section that matches the regex pattern is extracted
# and used as the process class name.
# For example, (java application -Denabled=true), and by default, it extracts the first word (java). Therefore,
# all java process are classified together.
export PROCESS_CLASS_REGEX="${PROCESS_CLASS_BY_NAME}"

# The minimum time the process is alive in seconds before we start monitoring.
# This is to prevent process monittoring overloading especially with short lived processes
export MIN_PROCESS_TIME_IN_SECONDS=60

# This variable sets the maximum number of process will be monitored.
export MAX_MONITORED_PROCESS=100