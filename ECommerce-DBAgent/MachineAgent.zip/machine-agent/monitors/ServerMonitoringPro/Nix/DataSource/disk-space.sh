#!/usr/bin/env bash
#
# Calculates Disk Space for system.
#
# For all Unixes, parses output from "df" command to calculate space.
#
# Copyright (c) AppDynamics, Inc., and its affiliates, 2014, 2015
# All Rights Reserved
# THIS IS UNPUBLISHED PROPRIETARY CODE OF APPDYNAMICS, INC.
# The copyright notice above does not evidence any
# actual or intended publication of such source code.

source "${SCRIPT_DIR}/utils.sh"
source "${SCRIPT_DIR}/common.sh"

DEV_DIR='/dev'

# Executes the command to gather inputs to the parser for linux 2.6.0
# and output the result in stdout
# Usage: gather_linux_ge_2_6_0
# Parameter: None
# Stdin: None
# Stdout: Result of executing the meminfo command
# Stderr: None
# Return: None
gather_linux_ge_2_6_0() {
    df -P -m
}

# Parses the output from gather() and outputs metrics for linux 2.6.0
#
# Usage: parse_linux_ge_2_6_0
# Parameter: None
# Stdin: Data to parse from executing gather command
# Stdout: Formatted data for reporting Metric
# Stderr: None
# Return: None
parse_linux_ge_2_6_0 () {
    capture_stdin
    local input="$UTILS_CAPTURED_STDIN"

    local awk_script='
        BEGIN {
            prefix = "Hardware Resources|Volumes|"
        }

        $1 ~ "^" devDir {
            partition = $1
            total = $2
            used = $3
            free = $4
            mount_point = $6

            prefix_mount = prefix mount_point "|"
            print_metric(prefix_mount "Total (MB)", total)
            print_metric(prefix_mount "Used (MB)", used)
            print_metric(prefix_mount "Free (MB)", free)

            if (!(seen[partition])) {
                seen[partition] = 1
                total_sum += total
                used_sum += used
                free_sum += free
            }

            # Remove "%" from the capacity
            capacity = $5;
            gsub(/%/, "", capacity);

            print_metric(prefix_mount "Used (%)", capacity)
        }

        END {
            print_metric(prefix "Total (MB)", total_sum)
            print_metric(prefix "Used (MB)", used_sum)
            print_metric(prefix "Free (MB)", free_sum)


            used_sum_percent = int(used_sum / total_sum * 100)
            print_metric(prefix "Used (%)", used_sum_percent)
        }
    '
    echo -n "${input}" | awk -v devDir="$DEV_DIR" -f <(cat "$SCRIPT_DIR/utils.awk") -f <(echo "$awk_script")

    echo -n "${input}" | parse_linux_ge_2_6_0_properties
}

# Parses the output from gather() and outputs properties for linux 2.6.0
#
# Usage: parse_linux_ge_2_6_0_properties
# Parameters: None
# Stdin: Data to parse from executing gather command
# Stdout: Formatted data for reporting metrics and properties
# Stderr: None
# Return: None
parse_linux_ge_2_6_0_properties() {
    local awk_script='
        function getRealLink(symlink,       temp_cmd, result) {
            temp_cmd="readlink -m " symlink
            temp_cmd | getline result;
            close(temp_cmd)
            return result
        }

        function getBaseName(path,      temp_cmd, result) {
            temp_cmd="basename " path
            temp_cmd | getline result;
            close(temp_cmd)
            return result
        }

        $1 ~ "^" devDir {

            partition = $1
            size = $2
            mount_point = $6
            real_path = getRealLink(partition)
            name = getBaseName(real_path)

            prefix = "Volume|" mount_point "|"
            print_property(prefix "Partition", name)
            print_property(prefix "Size (MB)", size)
            print_property(prefix "MountPoint", mount_point)
        }
    '
    awk -v devDir="$DEV_DIR" -f <(cat "$SCRIPT_DIR/utils.awk") -f <(echo "$awk_script")
}
