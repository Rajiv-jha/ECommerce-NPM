#!/usr/bin/bash
#
# Monitors CPU, Memory, Network and Disks on Solaris
#
# version 2.16
#
#########################################
#
# depends on /usr/bin/awk /usr/bin/kstat /usr/bin/iostat /usr/sbin/prtconf
#            /usr/bin/expr
#
# produce a report, once per minute, which contains lots of machine statistics
#
# edit the following to enable additional reporting options
# set to 0 or 1, depending on whether you want:
# DO_DISK: detailed disk i/o
# DO_FS: fs space
# DO_BLOCKS: packets and blocks in and out
# DO_IF: detailed network interface
DO_DISK=0
DO_FS=0
DO_BLOCKS=1
DO_IF=0

LOOPTIME=60

# this is how long we wait between network samples to calculate a delta.
SAMPLE=10

# this does not vary per run, so it is factored out of the loop
MEM_TOTAL_MB=`/usr/sbin/prtconf 2>/dev/null | /usr/bin/awk '/^Memory size/ { print $3 }'`
PAGESIZE=`/usr/bin/pagesize`

# forever
while [ 1 ]; do

        NOW=`perl -e 'print time'`
        NEXTSECONDS=`expr $NOW + $LOOPTIME`

# MEMORY usage

MEM_FREE_PAGES=`/usr/bin/kstat -p unix::system_pages:freemem | cut -f 2`
MEM_FREE_MB=`/usr/bin/expr $MEM_FREE_PAGES \* $PAGESIZE / 1048576`

MEM_USED_MB=`/usr/bin/expr $MEM_TOTAL_MB - $MEM_FREE_MB`
MEM_USED_PC=`/usr/bin/expr $MEM_USED_MB \* 100 / $MEM_TOTAL_MB`
MEM_FREE_PC=`/usr/bin/expr 100 - $MEM_USED_PC`

echo "name=Hardware Resources|Memory|Total (MB),aggregator=OBSERVATION,value="$MEM_TOTAL_MB
echo "name=Hardware Resources|Memory|Used (MB),aggregator=OBSERVATION,value="$MEM_USED_MB
echo "name=Hardware Resources|Memory|Free (MB),aggregator=OBSERVATION,value="$MEM_FREE_MB
echo "name=Hardware Resources|Memory|Used %,aggregator=OBSERVATION,value="$MEM_USED_PC
echo "name=Hardware Resources|Memory|Free %,aggregator=OBSERVATION,value="$MEM_FREE_PC

#
# this code works as follows: the first time we see a network interface 
# or disk, we set seen to 2. the next time, we set it to 4.
# then, whenever we see a statistic, we subtract 3 from this magic number.
# this gives us a -1 or a 1.  this is what we multiply the statistic by
# and accumulate it.  given exactly two samples, this means that it is a
# delta between the two samples.
#
# furthermore, we iterate over all the interfaces we have, so that we sum all 
# the interface rates for our final output.
#
# any network interface not having a ierror is ignored, being some kind
# of virtual tunnel or something. we only report real_interface[] stats.
#
# finally, we divide by the number of seconds between samples
#
/usr/bin/kstat -T u -c "/net|disk|nfs/" $SAMPLE 2 | /usr/bin/awk '
	BEGIN { OFS = ""; }
	/^[0-9]+/ { if (seconds) { seconds += $1; } else { seconds = - $1; } }
	/^module:/ { next; }
	/^name:/ { 
		name=$2; 
		type = $4;
		if (type == "net") {
			netseen[name] += 2; 
		} else {
			diskseen[name] += 2;
		}
	}
	$1 == "ierrors" && name != "mac" { real_interface[name] = 1; }

	$1 == "opackets" { np_out[name] += $2 * (netseen[name] - 3);}
	$1 == "ipackets" { np_in[name] += $2 * (netseen[name] - 3);}
	$1 == "obytes" { nb_out[name] += $2 * (netseen[name] - 3);}
	$1 == "rbytes" { nb_in[name] += $2 * (netseen[name] - 3);}

	$1 == "nread" { din[name] += $2 * (diskseen[name] - 3);}
	$1 == "nwritten" { dout[name] += $2 * (diskseen[name] - 3);}
	$1 == "writes" { dwrites[name] += $2 * (diskseen[name] - 3);}
	$1 == "reads" { dreads[name] += $2 * (diskseen[name] - 3);}

	END {
		for (ifname in netseen) {
			if (real_interface[ifname] == 0) {
				continue;
			}
if (NET == 1) {
if (BLOCKS == 1) {
		print "name=Hardware Resources|Network|",ifname,"|Incoming packets/sec,aggregator=OBSERVATION,value=", int(np_in[ifname]/seconds);
		print "name=Hardware Resources|Network|",ifname,"|Outgoing packets/sec,aggregator=OBSERVATION,value=", int(np_out[ifname]/seconds);
}
		print "name=Hardware Resources|Network|",ifname,"|Incoming KB/sec,aggregator=OBSERVATION,value=", int(((nb_in[ifname]/seconds) + 1023) / 1024);
		print "name=Hardware Resources|Network|",ifname,"|Outgoing KB/sec,aggregator=OBSERVATION,value=", int(((nb_out[ifname]/seconds) + 1023) / 1024);
}
			kb_in += nb_in[ifname];
			kb_out += nb_out[ifname];
			pkt_out += np_out[ifname];
			pkt_in += np_in[ifname];
		}	
		for (disk in diskseen) {
if (DISKS == 1) {
if (BLOCKS == 1) {
print "name=Hardware Resources|Disks|",disk,"|Reads/sec,aggregator=OBSERVATION,value=", int(dread[disk]/seconds);
print "name=Hardware Resources|Disks|",disk,"|Writes/sec,aggregator=OBSERVATION,value=", int(dwrite[disk]/seconds);
}
print "name=Hardware Resources|Disks|",disk,"|KB read/sec,aggregator=OBSERVATION,value=", int(((din[disk]/seconds) + 1023) / 1024);
print "name=Hardware Resources|Disks|",disk,"|KB written/sec,aggregator=OBSERVATION,value=", int(((dout[disk]/seconds) + 1023) / 1024);
}
			disk_in += din[disk];
			disk_out += dout[disk];
			disk_writes += dwrites[disk];
			disk_reads += dreads[disk];
		}	

		kb_in = int(((kb_in / seconds) + 1023) / 1024);
		kb_out = int(((kb_out / seconds) + 1023) / 1024);
		disk_in = int(((disk_in / seconds) + 1023) / 1024);
		disk_out = int(((disk_out / seconds) + 1023) / 1024);

		pkt_in = int(pkt_in / seconds);
		pkt_out = int(pkt_out / seconds);
		disk_reads = int(disk_reads / seconds);
		disk_writes = int(disk_writes / seconds);

if (BLOCKS) {
		print "name=Hardware Resources|Network|Incoming packets/sec,aggregator=OBSERVATION,value=", pkt_in;
		print "name=Hardware Resources|Network|Outgoing packets/sec,aggregator=OBSERVATION,value=", pkt_out;
		print "name=Hardware Resources|Disks|Reads/sec,aggregator=OBSERVATION,value=", disk_reads;
		print "name=Hardware Resources|Disks|Writes/sec,aggregator=OBSERVATION,value=", disk_writes;
}
		print "name=Hardware Resources|Network|Incoming KB/sec,aggregator=OBSERVATION,value=", kb_in;
		print "name=Hardware Resources|Network|Outgoing KB/sec,aggregator=OBSERVATION,value=", kb_out;
		print "name=Hardware Resources|Disks|KB read/sec,aggregator=OBSERVATION,value=", disk_in;
		print "name=Hardware Resources|Disks|KB written/sec,aggregator=OBSERVATION,value=", disk_out;
	}
' DISKS=$DO_DISK BLOCKS=$DO_BLOCKS NET=$DO_IF

# CPU

#
# Check if the zonename(1) utility exists.  If not, this system is likely running
# Solaris 8 or 9, so use vmstat(1m) to gather the CPU utilization.
#
ZONENAME=$(which zonename)

if [[ -x "${ZONENAME}" ]]; then
    zone=`${ZONENAME}`
    CPU_BUSY_TEMP=`prstat -Z 1 1 | grep $zone | awk ' { print $7 } ' | sed 's/%//'`
    CPU_BUSY=`printf "%0.f\n" $CPU_BUSY_TEMP`
    CPU_IDLE=`expr 100 - $CPU_BUSY`
else
    CPU_IDLE_TEMP=`vmstat 1 2 | tail -1 | awk '{print $22}'`
    CPU_IDLE=${CPU_IDLE_TEMP}
    CPU_BUSY=`expr 100 - $CPU_IDLE`
fi

echo "name=Hardware Resources|CPU|%Idle,aggregator=OBSERVATION,value="$CPU_IDLE
echo "name=Hardware Resources|CPU|%Busy,aggregator=OBSERVATION,value="$CPU_BUSY

#
# solaris df output
#
if [ $DO_FS == 1 ] ; then
(df -gk -F nfs ; df -gk -F ufs ; df -gk -F zfs) | /usr/bin/awk '
BEGIN { OFS=""; }
/\(/ { mountpt = substr($0,1,index($0,"(")-1);
	if (index(mountpt," ")) {
		mountpt = substr(mountpt,1,index(mountpt," ")-1);
	}
}
(NF == 11) {
	total = int($1/2);
	free = int($4/2);
	available = int($7/2);
	print "name=Hardware Resources|Filesystems|", mountpt, "|Total KB,aggregator=OBSERVATION,value=", total; 
	print "name=Hardware Resources|Filesystems|", mountpt, "|Used KB,aggregator=OBSERVATION,value=", total-free; 
	print "name=Hardware Resources|Filesystems|", mountpt, "|Available KB,aggregator=OBSERVATION,value=", available; 
}'
fi

	NOW=`perl -e 'print time'`

	SLEEPTIME=`expr $NEXTSECONDS - $NOW`
	if [ $SLEEPTIME -gt 0 ] ; then
		sleep $SLEEPTIME
	fi
done
